import java.util.Comparator;

import components.map.Map;
import components.map.Map2;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine2;
import components.utilities.FormatChecker;

/**
 * Program to count word occurrences in a given input file and generate a tag
 * cloud with an input number of words. Words are generated in alphabetical
 * order and sized by occurrence count.
 *
 * @author Jamie Bossenbroek, Derek Nelson, Ryan Ulring
 *
 */
public final class TagCloudGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator() {
    }

    /**
     * Comparator to sort in numerical order.
     */
    private static class IntegerComparator
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        public int compare(Map.Pair<String, Integer> arg0,
                Map.Pair<String, Integer> arg1) {
            return arg1.value().compareTo(arg0.value());
        }
    }

    /**
     * Comparator to sort in alphabetical order.
     */
    private static class StringComparator
            implements Comparator<Map.Pair<String, Integer>> {

        @Override
        public int compare(Map.Pair<String, Integer> arg0,
                Map.Pair<String, Integer> arg1) {
            int comp = String.CASE_INSENSITIVE_ORDER.compare(arg0.key(),
                    arg1.key());
            if (comp == 0) {
                comp = arg0.key().toLowerCase()
                        .compareTo(arg1.key().toLowerCase());
            }
            return comp;
        }
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @requires str and strSet are not null
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        if (str.length() > 1) {
            char sub = str.charAt(0);
            strSet.add(sub);
            generateElements(str.substring(1), strSet);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        boolean regulator = separators.contains(text.charAt(position));
        int counter = position;
        while (counter < text.length()
                && regulator == separators.contains(text.charAt(counter))) {
            counter++;
        }
        return text.substring(position, counter);
    }

    /**
     * Saves words from given input file into {@code Map} with associated
     * occurrence counts.
     *
     * @param in
     *            SimpleReader for the input file
     * @param count
     *            the {@code Map} of words and associated occurrence counts
     * @param separatorSet
     *            the {@code Set} of separator characters
     * @replaces count
     * @requires in is a valid input
     * @ensures count = entries(input), with words matching to their correct
     *          occurrence count
     */
    private static void createMapOfWords(SimpleReader in,
            Map<String, Integer> count, Set<Character> separatorSet) {

        while (!in.atEOS()) {
            String line = in.nextLine();
            int position = 0;
            while (position < line.length()) {
                String token = nextWordOrSeparator(line, position,
                        separatorSet);
                //Additional activity #2
                token = token.toLowerCase();
                if (!separatorSet.contains(token.charAt(0))) {
                    if (!count.hasKey(token)) {
                        count.add(token, 1);
                    } else {
                        count.replaceValue(token, count.value(token) + 1);
                    }
                }
                position += token.length();
            }
        }
        in.close();
    }

    /**
     * Orders the {@code Map} of words into the {@code SortingMachine} by
     * occurrence count.
     *
     * @param words
     *            the {@code Map} containing pairs of words and their occurrence
     *            counts
     * @param largestValues
     *            the {@code SortingMachine} that orders {@code Map} by the
     *            amount of times each word appears
     * @updates largestValues
     * @requires |largestValues| = 0 and largestValues is in insertion mode
     * @ensure largestValues has every element of words sorted by the amount of
     *         times the word appears
     */
    private static void orderByFrequency(Map<String, Integer> words,
            SortingMachine<Map.Pair<String, Integer>> largestValues) {
        assert largestValues.size() == 0 : "Violation of: |largestValues| = 0";
        assert largestValues
                .isInInsertionMode() : "Violation of: largestValues is in insertion mode";

        for (Map.Pair<String, Integer> p : words) {
            largestValues.add(p);
        }
        largestValues.changeToExtractionMode();
    }

    /**
     * Alphabetizes the first n keys of the {@code Map}.
     *
     * @param largestValues
     *            the {@code SortingMachine} containing every term and its
     *            occurrence count sorted by frequency.
     * @param alphabeticKeys
     *            the {@code SortingMachine} object to store terms
     *            alphabetically.
     * @param n
     *            The number of words to alphabetize
     * @updates largestValues, alphabeticKeys
     * @requires |alphabeticKeys| = 0 and alphebeticKeys is in insertion mode
     *           and largestValues is in extraction mode
     * @ensures alphabeticKeys contains the first n words of largestValues
     *          ordered alphabetically
     */
    private static void alphabetize(
            SortingMachine<Map.Pair<String, Integer>> largestValues,
            SortingMachine<Map.Pair<String, Integer>> alphabeticKeys, int n) {
        assert alphabeticKeys
                .size() == 0 : "Violation of: |alphabeticKeys| = 0";
        assert alphabeticKeys.isInInsertionMode() : "Violation of: "
                + "alphabeticKeys is in insertion mode";
        assert !largestValues.isInInsertionMode() : "Violation of: "
                + "largestValues is in extraction mode";

        int counter = 0;
        while (counter < n && largestValues.size() > 0) {
            alphabeticKeys.add(largestValues.removeFirst());
            counter++;
        }
        alphabeticKeys.changeToExtractionMode();
    }

    /**
     * Determines the appropriate font size for value given minimum and maximum
     * boundaries.
     *
     * @param min
     *            the minimum boundary
     * @param max
     *            the maximum boundary
     * @param value
     *            the value for which to determine font size
     * @return the font size for value
     * @requires min, and max are >= 0 and min <= value <= max
     * @ensures value <= 38 and value >= 11 and value is scaled based on max and
     *          min
     */
    public static int getFontSize(int min, int max, int value) {
        double fontSize = (37.0 / (max - min)) * (value - min) + 11;
        return (int) fontSize;
    }

    /**
     * Generates a tag cloud of the words in the {@code SortingMachine}, with
     * words in alphabetical order and sized by occurrence count.
     *
     * @param title
     *            the name of the file
     * @param fileOut
     *            the output file to generate tag cloud to
     * @param alphabeticKeys
     *            the {@code SortingMachine} containing words in alphabetical
     *            order
     * @clears lexographicKeys
     * @updates fileOut
     * @requires title is not null and fileOut is an empty file
     * @ensures {@code fileOut} contains tag cloud of words in alphabetical
     *          order sized by occurrence count
     */
    private static void generateTagCloud(String title, SimpleWriter fileOut,
            SortingMachine<Map.Pair<String, Integer>> alphabeticKeys) {
        assert title != null : "Violation of title is not null";

        /*
         * Output header
         */
        fileOut.println("<html>\n<head>");
        fileOut.println("<title>Top " + alphabeticKeys.size() + " words in "
                + title + "</title>");
        fileOut.println(
                "<link href=\"http://web.cse.ohio-state.edu/software/2231/"
                        + "web-sw2/assignments/projects/tag-cloud-generator/data/"
                        + "tagcloud.css\" rel=\"stylesheet\" type=\"text/css\">");
        fileOut.println("</head>\n<body>");
        fileOut.println("<h1>Top " + alphabeticKeys.size() + " words in "
                + title + "</h1>");
        /*
         * Determine maximum and minimum occurrence count values
         */
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (Map.Pair<String, Integer> p : alphabeticKeys) {
            if (p.value() < min) {
                min = p.value();
            }
            if (p.value() > max) {
                max = p.value();
            }
        }
        /*
         * Output tag cloud
         */
        fileOut.println("<hr><div class=\"cdiv\">\r\n" + "<p class=\"cbox\">");
        while (alphabeticKeys.size() > 0) {
            Map.Pair<String, Integer> p = alphabeticKeys.removeFirst();
            int fontSize = getFontSize(min, max, p.value());
            fileOut.println("<span style=\"cursor:default\" class=\"f"
                    + fontSize + "\" title=\"count: " + p.value() + "\">"
                    + p.key() + "</span>");
        }
        /*
         * Output footer
         */
        fileOut.println("</p></div></body></html>");
        fileOut.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        /*
         * Create set of separator characters
         */
        final String separatorStr = " \t\n\r,-.!?';:/\"`*_[]{}() ";
        Set<Character> separatorSet = new Set1L<>();
        generateElements(separatorStr, separatorSet);
        /*
         * Open input and output streams
         */
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Ask for name of input file
         */
        out.println("Enter name of input file: ");
        String inputFile = in.nextLine();
        SimpleReader inputText = new SimpleReader1L(inputFile);
        int numberOfWords;
        /*
         * Ask for name of output file
         */
        out.println("Enter the name of the output file: ");
        String outputFile = in.nextLine();
        SimpleWriter fileOut = new SimpleWriter1L(outputFile);
        /*
         * Create map of words and occurrences
         */
        Map<String, Integer> occurrences = new Map2<>();
        createMapOfWords(inputText, occurrences, separatorSet);
        /*
         * Ask for number of words to be included in tag cloud
         */
        out.println("Enter number of words to be added to the tag cloud: ");
        String numberOfWordsString = in.nextLine();
        while (!FormatChecker.canParseInt(numberOfWordsString)
                || !(Integer.parseInt(numberOfWordsString) <= occurrences
                        .size())
                || !(Integer.parseInt(numberOfWordsString) >= 0)) {
            out.println("Enter a valid positive integer that is less "
                    + "than the number of unique words in " + inputFile);
            numberOfWordsString = in.nextLine();
        }
        numberOfWords = Integer.parseInt(numberOfWordsString);
        /*
         * Sort all words by occurrence count
         */
        IntegerComparator order = new IntegerComparator();
        SortingMachine<Map.Pair<String, Integer>> largestValues;
        largestValues = new SortingMachine2<Map.Pair<String, Integer>>(order);
        orderByFrequency(occurrences, largestValues);
        /*
         * Sort first n words alphabetically
         */
        StringComparator alphabeticOrder = new StringComparator();
        SortingMachine<Map.Pair<String, Integer>> alphabeticKeys;
        alphabeticKeys = new SortingMachine2<Map.Pair<String, Integer>>(
                alphabeticOrder);
        alphabetize(largestValues, alphabeticKeys, numberOfWords);
        /*
         * Generate tag cloud of first n words
         */
        generateTagCloud(inputFile, fileOut, alphabeticKeys);
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }
}
